from django.apps import AppConfig


class DilscodesappConfig(AppConfig):
    name = 'dilsCodesApp'
